#!/bin/bash
SETUSER="svcapp"
RUNNER=`whoami`

if [ $RUNNER != $SETUSER ] ;
	then echo "Deny Access : [ $RUNNER ]. Not $SETUSER" ;
	exit 0 ;
fi

/skt/web/httpd/bin/apachectl -k stop
